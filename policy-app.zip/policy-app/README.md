# 정책자금 캘린더 — 배포 가이드

## 1단계: 공공데이터포털 API 키 발급 (5분)

1. https://www.data.go.kr 접속 → 회원가입/로그인
2. 상단 검색창에 **"소상공인 지원사업"** 검색
3. **"소상공인시장진흥공단_소상공인 지원사업 정보"** 클릭
4. **[활용신청]** 버튼 클릭 → 즉시 발급 (자동승인)
5. 마이페이지 → API 키 복사

## 2단계: GitHub에 올리기 (3분)

```bash
cd policy-app
git init
git add .
git commit -m "정책자금 캘린더"
```

GitHub.com → New Repository → 업로드

## 3단계: Vercel 배포 (3분)

1. https://vercel.com 접속 → GitHub 로그인
2. **[New Project]** → GitHub 저장소 선택
3. **Environment Variables** 추가:
   - Key: `PUBLIC_DATA_API_KEY`
   - Value: 1단계에서 발급받은 API 키
4. **[Deploy]** 클릭 → 완료!

## 완료 후

- 실제 URL 생성됨 (예: policy-calendar.vercel.app)
- 공공데이터포털 실시간 연동
- API 실패 시 자동으로 기본 데이터 표시

## 연동 API 목록

| API | 기관 | 데이터 |
|-----|------|--------|
| 소상공인 지원사업 | 소진공 | 지원사업 목록, 마감일, 금액 |
| 정책자금 정보 | 중기부 | 융자·보조금·보증 정보 |

## 추후 추가 가능한 API

- 소상공인 창업 지원 (소진공)
- 지역별 특화 지원사업 (각 지자체)
- 고용노동부 일자리 지원금
