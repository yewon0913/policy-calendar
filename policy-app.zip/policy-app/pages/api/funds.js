// pages/api/funds.js
// 공공데이터포털 소상공인 지원사업 API 프록시
// CORS 문제를 서버 사이드에서 해결

export default async function handler(req, res) {
  const { month, type, region } = req.query;
  const API_KEY = process.env.PUBLIC_DATA_API_KEY;

  if (!API_KEY) {
    return res.status(500).json({ error: "API 키가 설정되지 않았습니다. .env.local 파일을 확인하세요." });
  }

  try {
    // 1. 소진공 지원사업 API
    const sbizUrl = new URL("https://www.sbiz.or.kr/openapi/bsns/getBsnsSportBizList.do");
    sbizUrl.searchParams.set("serviceKey", API_KEY);
    sbizUrl.searchParams.set("pageNo", "1");
    sbizUrl.searchParams.set("numOfRows", "100");
    sbizUrl.searchParams.set("type", "json");
    if (region && region !== "전국") sbizUrl.searchParams.set("rgn", region);

    const sbizRes = await fetch(sbizUrl.toString());
    const sbizData = await sbizRes.json();
    const sbizItems = sbizData?.response?.body?.items?.item || [];

    // 2. 중소벤처기업부 정책자금 API (data.go.kr)
    const smbaUrl = new URL("https://apis.data.go.kr/1130000/MsmeSupportPolicyFundService/getMsmeSupportPolicyFundList");
    smbaUrl.searchParams.set("serviceKey", API_KEY);
    smbaUrl.searchParams.set("pageNo", "1");
    smbaUrl.searchParams.set("numOfRows", "100");
    smbaUrl.searchParams.set("type", "json");

    const smbaRes = await fetch(smbaUrl.toString());
    const smbaData = await smbaRes.json();
    const smbaItems = smbaData?.response?.body?.items?.item || [];

    // 3. 데이터 정규화
    const normalize = (items, source) => items.map((item, idx) => ({
      id: source + "_" + (item.bsnsSportBizSn || item.policyFundNo || idx),
      name: item.bsnsSportBizNm || item.policyFundNm || "지원사업",
      org: item.mngtInstNm || item.supInstNm || source,
      type: guessType(item.bsnsSportBizNm || item.policyFundNm || ""),
      amount: item.mxmSportAmt ? Number(item.mxmSportAmt).toLocaleString() + "원" : item.fundAmt || "공고 확인",
      deadline: item.rcptEndDt || item.applyEndDe || "연중상시",
      target: item.applcTrgtNm || item.sprtTrgt || "소상공인",
      region: item.rgnNm || "전국",
      sector: item.bsnsSportBizTypeNm || "전업종",
      desc: item.bsnsSportBizCn || item.policyFundDtlCn || "",
      url: item.dtlUrl || item.applyUrl || "https://ols.sbiz.or.kr",
      rate: item.intrRt ? item.intrRt + "%" : "-",
      month: extractMonth(item.rcptEndDt || item.applyEndDe || ""),
      raw: item,
    }));

    const all = [
      ...normalize(Array.isArray(sbizItems) ? sbizItems : [sbizItems], "소진공"),
      ...normalize(Array.isArray(smbaItems) ? smbaItems : [smbaItems], "중기부"),
    ];

    // 4. 필터링
    let filtered = all.filter(f => f.name !== "지원사업");
    if (month) filtered = filtered.filter(f => f.month === parseInt(month));
    if (type && type !== "전체") filtered = filtered.filter(f => f.type === type);
    if (region && region !== "전국") filtered = filtered.filter(f => f.region === "전국" || f.region.includes(region));

    res.status(200).json({
      success: true,
      total: filtered.length,
      items: filtered,
      sources: ["소진공", "중기부"],
      updatedAt: new Date().toISOString(),
    });

  } catch (error) {
    console.error("API 오류:", error);
    // API 실패 시 fallback 데이터 반환
    res.status(200).json({
      success: false,
      error: error.message,
      items: getFallbackData(month, type, region),
      isFallback: true,
    });
  }
}

function guessType(name) {
  if (name.includes("융자") || name.includes("대출") || name.includes("자금")) return "융자";
  if (name.includes("보증")) return "보증";
  return "보조금";
}

function extractMonth(dateStr) {
  if (!dateStr) return new Date().getMonth() + 1;
  const m = String(dateStr).match(/(\d{4})[.\-\/]?(\d{2})/);
  return m ? parseInt(m[2]) : new Date().getMonth() + 1;
}

// API 실패 시 기본 데이터 (항상 무언가 보여주기 위해)
function getFallbackData(month, type, region) {
  const FALLBACK = [
    { id:"f1", name:"소상공인 경영안정자금", org:"소진공", type:"융자", amount:"최대 7천만원", rate:"3.4%", deadline:"연중상시", target:"업력 1년 이상 소상공인", region:"전국", sector:"전업종", desc:"경영 위기 소상공인 긴급 운영자금", url:"https://ols.sbiz.or.kr", month:1 },
    { id:"f2", name:"소상공인 스마트 상점", org:"소진공", type:"보조금", amount:"최대 1천만원", rate:"-", deadline:"연중상시", target:"오프라인 매장 소상공인", region:"전국", sector:"전업종", desc:"스마트기술(AI·IoT·키오스크) 도입 지원", url:"https://ols.sbiz.or.kr", month:2 },
    { id:"f3", name:"창업기업 지원자금", org:"중진공", type:"융자", amount:"최대 1억원", rate:"2.9%", deadline:"연중상시", target:"업력 7년 이내", region:"전국", sector:"전업종", desc:"창업 초기 시설·운전자금 저금리 지원", url:"https://www.kosmes.or.kr", month:3 },
    { id:"f4", name:"지역신용보증 특례", org:"지역신보", type:"보증", amount:"최대 1억원", rate:"보증료 0.5%", deadline:"연중상시", target:"담보 부족 소상공인", region:"전국", sector:"전업종", desc:"담보 없이 보증 지원", url:"https://koreg.or.kr", month:4 },
    { id:"f5", name:"온라인 판로 개척", org:"소진공", type:"보조금", amount:"최대 400만원", rate:"-", deadline:"연중상시", target:"연매출 10억 미만", region:"전국", sector:"전업종", desc:"스마트스토어·쿠팡 입점 지원", url:"https://ols.sbiz.or.kr", month:5 },
  ];
  return FALLBACK;
}
