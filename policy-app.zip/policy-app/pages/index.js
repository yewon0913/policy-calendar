// pages/index.js
import { useState, useEffect, useCallback } from "react";

const MONTHS = ["1월","2월","3월","4월","5월","6월","7월","8월","9월","10월","11월","12월"];
const TYPES = ["전체","융자","보조금","보증"];
const REGIONS = ["전국","서울","경기","부산","인천","대구","광주","대전","울산","세종","강원","충북","충남","전북","전남","경북","경남","제주"];
const SECTORS = ["전업종","외식·음식","제조업","유통·소매","서비스업","IT·기술"];
const TYPE_COLOR = { "융자":"#4f7cf8", "보조금":"#22c55e", "보증":"#f59e0b" };

export default function PolicyCalendar() {
  const today = new Date();
  const [month, setMonth] = useState(today.getMonth());
  const [type, setType] = useState("전체");
  const [region, setRegion] = useState("전국");
  const [sector, setSector] = useState("전업종");
  const [funds, setFunds] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isFallback, setIsFallback] = useState(false);
  const [sel, setSel] = useState(null);
  const [view, setView] = useState("calendar");
  const [lastUpdated, setLastUpdated] = useState(null);

  const fetchFunds = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ month: month + 1 });
      if (type !== "전체") params.set("type", type);
      if (region !== "전국") params.set("region", region);
      const res = await fetch("/api/funds?" + params.toString());
      const data = await res.json();
      setFunds(data.items || []);
      setIsFallback(!!data.isFallback);
      setLastUpdated(data.updatedAt ? new Date(data.updatedAt) : null);
    } catch {
      setFunds([]);
    }
    setLoading(false);
  }, [month, type, region]);

  useEffect(() => { fetchFunds(); }, [fetchFunds]);

  const filtered = funds.filter(f =>
    sector === "전업종" || f.sector === "전업종" || (f.sector || "").includes(sector)
  );

  // 통계용 — 전체 데이터
  const [allFunds, setAllFunds] = useState([]);
  useEffect(() => {
    fetch("/api/funds").then(r => r.json()).then(d => setAllFunds(d.items || []));
  }, []);

  const stats = MONTHS.map((m, i) => {
    const mf = allFunds.filter(f => f.month === i + 1);
    return {
      m, count: mf.length,
      융자: mf.filter(f => f.type === "융자").length,
      보조금: mf.filter(f => f.type === "보조금").length,
      보증: mf.filter(f => f.type === "보증").length,
    };
  });
  const maxCount = Math.max(...stats.map(s => s.count), 1);

  const bg = "#07090f", card = "#0d1117", border = "#1c2535";
  const muted = "#4b5563", acc = "#4f7cf8", grn = "#22c55e", gold = "#f59e0b";

  return (
    <div style={{ minHeight:"100vh", background:bg, fontFamily:"'Apple SD Gothic Neo','Noto Sans KR',sans-serif", color:"#fff", maxWidth:480, margin:"0 auto" }}>
      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { background: ${bg}; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes fadeIn { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }
        .fade { animation: fadeIn .2s ease forwards; }
        ::-webkit-scrollbar { width:3px; height:3px; }
        ::-webkit-scrollbar-thumb { background:#1c2535; border-radius:3px; }
      `}</style>

      {/* 헤더 */}
      <div style={{ background:"#0d1117", borderBottom:"1px solid "+border, padding:"14px 16px", position:"sticky", top:0, zIndex:100 }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
          <div>
            <div style={{ fontSize:18, fontWeight:900 }}>💰 정책자금 캘린더</div>
            <div style={{ display:"flex", alignItems:"center", gap:6, marginTop:2 }}>
              {isFallback
                ? <span style={{ fontSize:9, background:"#ef444420", color:"#ef4444", padding:"2px 7px", borderRadius:10 }}>⚠️ API 연결 안됨 — 기본 데이터</span>
                : <span style={{ fontSize:9, background:grn+"20", color:grn, padding:"2px 7px", borderRadius:10 }}>🟢 실시간 연동</span>
              }
              {lastUpdated && <span style={{ fontSize:9, color:muted }}>{lastUpdated.toLocaleTimeString("ko-KR")} 업데이트</span>}
            </div>
          </div>
          <div style={{ display:"flex", gap:6 }}>
            <button onClick={fetchFunds} disabled={loading} style={{ width:32, height:32, borderRadius:"50%", border:"1px solid "+border, background:"transparent", color:muted, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontSize:14 }}>
              <span style={{ display:"inline-block", animation:loading?"spin 1s linear infinite":"none" }}>🔄</span>
            </button>
            {["calendar","stats"].map(v => (
              <button key={v} onClick={()=>setView(v)} style={{ padding:"6px 12px", background:view===v?acc+"20":"transparent", border:"1px solid "+(view===v?acc:border), borderRadius:16, color:view===v?acc:muted, fontSize:10, fontWeight:view===v?700:400, cursor:"pointer" }}>
                {v==="calendar"?"📅":"📊"}
              </button>
            ))}
          </div>
        </div>

        {/* 필터 */}
        <div style={{ display:"flex", gap:5, overflowX:"auto", paddingBottom:2 }}>
          {TYPES.map(t => (
            <button key={t} onClick={()=>setType(t)} style={{ flexShrink:0, padding:"4px 10px", background:type===t?(TYPE_COLOR[t]||acc)+"20":"transparent", border:"1px solid "+(type===t?(TYPE_COLOR[t]||acc):border), borderRadius:14, color:type===t?(TYPE_COLOR[t]||acc):muted, fontSize:10, fontWeight:type===t?700:400, cursor:"pointer" }}>
              {t}
            </button>
          ))}
          <div style={{ width:1, background:border, flexShrink:0 }} />
          <select value={region} onChange={e=>setRegion(e.target.value)} style={{ background:card, border:"1px solid "+border, borderRadius:14, color:"#fff", fontSize:10, padding:"4px 8px", cursor:"pointer" }}>
            {REGIONS.map(r => <option key={r}>{r}</option>)}
          </select>
          <select value={sector} onChange={e=>setSector(e.target.value)} style={{ background:card, border:"1px solid "+border, borderRadius:14, color:"#fff", fontSize:10, padding:"4px 8px", cursor:"pointer" }}>
            {SECTORS.map(s => <option key={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {view === "calendar" && (
        <>
          {/* 월 탭 */}
          <div style={{ display:"flex", overflowX:"auto", background:card, borderBottom:"1px solid "+border }}>
            {MONTHS.map((m, i) => {
              const cnt = allFunds.filter(f => f.month === i+1).length;
              return (
                <button key={m} onClick={()=>setMonth(i)} style={{ flexShrink:0, minWidth:50, padding:"9px 2px", background:"none", border:"none", borderBottom:"2.5px solid "+(month===i?acc:"transparent"), color:month===i?acc:muted, fontSize:10, fontWeight:month===i?800:400, cursor:"pointer", textAlign:"center", position:"relative" }}>
                  <div>{m}</div>
                  {cnt > 0 && <div style={{ fontSize:8, marginTop:2, background:month===i?acc:muted+"30", color:month===i?"#fff":muted, borderRadius:8, padding:"1px 4px" }}>{cnt}</div>}
                  {i === today.getMonth() && <div style={{ position:"absolute", top:3, right:4, width:4, height:4, borderRadius:"50%", background:grn }} />}
                </button>
              );
            })}
          </div>

          {/* 월 헤더 */}
          <div style={{ padding:"12px 16px 8px", background:"linear-gradient(180deg,#0f1520,#07090f)" }}>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between" }}>
              <div>
                <div style={{ fontSize:18, fontWeight:900 }}>{MONTHS[month]} 지원사업</div>
                <div style={{ fontSize:11, color:muted, marginTop:2 }}>
                  {loading ? "조회 중..." : `총 ${filtered.length}개`}
                  {isFallback && " (기본 데이터)"}
                </div>
              </div>
              <div style={{ display:"flex", gap:5 }}>
                {["융자","보조금","보증"].map(t => {
                  const c = filtered.filter(f=>f.type===t).length;
                  return c > 0 ? <div key={t} style={{ background:TYPE_COLOR[t]+"20", color:TYPE_COLOR[t], fontSize:9, padding:"3px 8px", borderRadius:10, fontWeight:700 }}>{t} {c}</div> : null;
                })}
              </div>
            </div>
          </div>

          {/* 목록 */}
          <div style={{ padding:"8px 14px 80px" }}>
            {loading && (
              <div style={{ textAlign:"center", padding:40, color:muted }}>
                <div style={{ fontSize:28, animation:"spin 1s linear infinite", display:"inline-block" }}>🔄</div>
                <div style={{ fontSize:13, marginTop:12 }}>공공데이터 실시간 조회 중...</div>
              </div>
            )}
            {!loading && filtered.length === 0 && (
              <div style={{ textAlign:"center", padding:50, color:muted }}>
                <div style={{ fontSize:36 }}>🔍</div>
                <div style={{ fontSize:14, marginTop:10 }}>해당 조건의 사업이 없습니다</div>
                <div style={{ fontSize:11, marginTop:6 }}>필터를 변경하거나 다른 달을 확인해보세요</div>
              </div>
            )}
            {!loading && filtered.map(f => (
              <div key={f.id} className="fade" onClick={()=>setSel(sel?.id===f.id?null:f)}
                style={{ background:card, border:"1px solid "+(sel?.id===f.id?TYPE_COLOR[f.type]||acc:border), borderRadius:16, padding:"13px 14px", marginBottom:9, cursor:"pointer" }}>
                <div style={{ display:"flex", alignItems:"flex-start", gap:11 }}>
                  <div style={{ width:42, height:42, borderRadius:12, background:(TYPE_COLOR[f.type]||acc)+"20", border:"1px solid "+(TYPE_COLOR[f.type]||acc)+"30", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                    <div style={{ fontSize:8, color:TYPE_COLOR[f.type]||acc, fontWeight:700 }}>{f.type}</div>
                    <div style={{ fontSize:16 }}>{f.type==="융자"?"🏦":f.type==="보조금"?"💸":"🛡️"}</div>
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:3, flexWrap:"wrap" }}>
                      <span style={{ fontSize:13, fontWeight:800 }}>{f.name}</span>
                      <span style={{ background:(TYPE_COLOR[f.type]||acc)+"20", color:TYPE_COLOR[f.type]||acc, fontSize:9, padding:"2px 6px", borderRadius:10, fontWeight:700 }}>{f.org}</span>
                      {f.region !== "전국" && <span style={{ background:"#8b5cf620", color:"#a78bfa", fontSize:9, padding:"2px 6px", borderRadius:10 }}>📍{f.region}</span>}
                    </div>
                    {f.desc && <div style={{ fontSize:11, color:muted, marginBottom:7, lineHeight:1.5 }}>{f.desc.slice(0,60)}{f.desc.length>60?"…":""}</div>}
                    <div style={{ display:"flex", gap:5, flexWrap:"wrap" }}>
                      <span style={{ background:grn+"15", color:grn, fontSize:10, padding:"2px 8px", borderRadius:10, fontWeight:700 }}>💰 {f.amount}</span>
                      <span style={{ background:"#ffffff08", color:"#6b7280", fontSize:10, padding:"2px 8px", borderRadius:10 }}>📅 ~{f.deadline}</span>
                    </div>
                  </div>
                </div>

                {sel?.id === f.id && (
                  <div style={{ marginTop:12, paddingTop:12, borderTop:"1px solid "+border }}>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:7, marginBottom:10 }}>
                      {[
                        { l:"지원 금액", v:f.amount, c:grn },
                        { l:"금리/보증료", v:f.rate||"-", c:acc },
                        { l:"신청 마감", v:f.deadline, c:gold },
                        { l:"지원 대상", v:f.target, c:"#a78bfa" },
                      ].map(s => (
                        <div key={s.l} style={{ background:"rgba(255,255,255,0.04)", borderRadius:9, padding:"8px 10px" }}>
                          <div style={{ fontSize:9, color:muted, marginBottom:2 }}>{s.l}</div>
                          <div style={{ fontSize:11, fontWeight:700, color:s.c }}>{s.v}</div>
                        </div>
                      ))}
                    </div>
                    {f.desc && <div style={{ fontSize:11, color:"#9ca3af", lineHeight:1.7, marginBottom:10, background:"rgba(255,255,255,0.03)", borderRadius:9, padding:"9px 11px" }}>{f.desc}</div>}
                    <div style={{ display:"flex", gap:7 }}>
                      <button onClick={e=>{e.stopPropagation();window.open(f.url,"_blank");}} style={{ flex:1, padding:10, background:acc+"20", border:"1px solid "+acc+"40", borderRadius:9, color:acc, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                        🔗 신청하기
                      </button>
                      <button onClick={e=>{e.stopPropagation();navigator.clipboard?.writeText(`${f.name}\n기관: ${f.org}\n금액: ${f.amount}\n마감: ${f.deadline}\n대상: ${f.target}\n신청: ${f.url}`);}} style={{ flex:1, padding:10, background:"rgba(255,255,255,0.05)", border:"1px solid "+border, borderRadius:9, color:muted, fontSize:12, fontWeight:700, cursor:"pointer" }}>
                        📋 복사
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </>
      )}

      {view === "stats" && (
        <div style={{ padding:"14px 14px 80px" }}>
          <div style={{ background:card, border:"1px solid "+border, borderRadius:16, padding:16, marginBottom:14 }}>
            <div style={{ fontSize:14, fontWeight:900, marginBottom:3 }}>📊 연간 공고 패턴</div>
            <div style={{ fontSize:11, color:muted, marginBottom:16 }}>어느 달에 지원사업이 집중되나요?</div>
            <div style={{ display:"flex", alignItems:"flex-end", gap:4, height:90 }}>
              {stats.map((s, i) => (
                <div key={s.m} onClick={()=>{setMonth(i);setView("calendar");}} style={{ flex:1, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:3 }}>
                  <div style={{ fontSize:8, color:i===today.getMonth()?grn:muted }}>{s.count||""}</div>
                  <div style={{ width:"100%", borderRadius:"3px 3px 0 0", overflow:"hidden", display:"flex", flexDirection:"column", height:s.count?(s.count/maxCount*70)+"px":"3px", minHeight:3 }}>
                    <div style={{ flex:s.보조금, background:grn+"cc" }} />
                    <div style={{ flex:s.융자, background:acc+"cc" }} />
                    <div style={{ flex:s.보증, background:gold+"cc" }} />
                  </div>
                  <div style={{ fontSize:7, color:i===month?acc:muted, fontWeight:i===month?800:400 }}>{s.m}</div>
                </div>
              ))}
            </div>
            <div style={{ display:"flex", gap:12, marginTop:12, justifyContent:"center" }}>
              {[["보조금",grn],["융자",acc],["보증",gold]].map(([t,c])=>(
                <div key={t} style={{ display:"flex", alignItems:"center", gap:4, fontSize:10, color:muted }}>
                  <div style={{ width:8, height:8, borderRadius:2, background:c }} />
                  {t}
                </div>
              ))}
            </div>
          </div>

          {/* 상위 지원금 요약 */}
          <div style={{ fontSize:13, fontWeight:800, marginBottom:10 }}>💡 주요 상시 지원사업</div>
          {allFunds.filter((_,i)=>i<10).map(f => (
            <div key={f.id} style={{ background:card, border:"1px solid "+border, borderRadius:12, padding:"11px 13px", marginBottom:8, display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ fontSize:18 }}>{f.type==="융자"?"🏦":f.type==="보조금"?"💸":"🛡️"}</div>
              <div style={{ flex:1, minWidth:0 }}>
                <div style={{ fontSize:12, fontWeight:700, marginBottom:2, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{f.name}</div>
                <div style={{ fontSize:10, color:muted }}>{f.org} · {f.amount}</div>
              </div>
              <div style={{ background:(TYPE_COLOR[f.type]||acc)+"20", color:TYPE_COLOR[f.type]||acc, fontSize:9, padding:"3px 8px", borderRadius:10, fontWeight:700, flexShrink:0 }}>{f.type}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
